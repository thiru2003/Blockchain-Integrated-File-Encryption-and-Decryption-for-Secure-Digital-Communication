export interface ConnectionStatus {
  isConnected: boolean;
  deviceId: string | null;
  networkType: 'dpn' | 'standard' | null;
  peers: number;
}

export interface TransferProgress {
  status: 'pending' | 'transferring' | 'completed' | 'failed';
  progress: number;
  message?: string;
}