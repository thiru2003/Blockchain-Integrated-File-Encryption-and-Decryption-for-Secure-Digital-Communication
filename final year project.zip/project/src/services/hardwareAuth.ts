import { ethers } from 'ethers';
import CryptoJS from 'crypto-js';

export interface HardwareDevice {
  deviceId: string;
  publicKey: string;
  isAuthenticated: boolean;
  lastAuthenticated?: Date;
}

class HardwareAuthService {
  private devices: Map<string, HardwareDevice>;
  private authKeys: Map<string, string>;

  constructor() {
    this.devices = new Map();
    this.authKeys = new Map();
  }

  async authenticateDevice(deviceId: string): Promise<boolean> {
    try {
      if (!deviceId) {
        throw new Error('Device ID is required');
      }

      // Generate device-specific salt
      const salt = CryptoJS.lib.WordArray.random(128/8);
      
      // Generate a new authentication key with additional entropy
      const randomBytes = ethers.randomBytes(32);
      const authKey = ethers.hexlify(randomBytes);
      
      // Create a more secure encryption key using PBKDF2
      const encryptionKey = CryptoJS.PBKDF2(
        authKey,
        salt.toString(),
        { keySize: 256/32, iterations: 1000 }
      ).toString();

      // Encrypt the authentication key
      const encryptedKey = CryptoJS.AES.encrypt(
        authKey,
        encryptionKey
      ).toString();
      
      this.authKeys.set(deviceId, encryptedKey);
      
      const device: HardwareDevice = {
        deviceId,
        publicKey: authKey,
        isAuthenticated: true,
        lastAuthenticated: new Date()
      };
      
      this.devices.set(deviceId, device);
      return true;
    } catch (error) {
      console.error('Device authentication failed:', error);
      return false;
    }
  }

  verifyDevice(deviceId: string): boolean {
    const device = this.devices.get(deviceId);
    if (!device) return false;
    
    // Check if device was authenticated in the last 24 hours
    const lastAuth = device.lastAuthenticated;
    if (!lastAuth) return false;
    
    const dayInMs = 24 * 60 * 60 * 1000;
    return Date.now() - lastAuth.getTime() < dayInMs;
  }

  getDeviceKey(deviceId: string): string | null {
    if (!this.verifyDevice(deviceId)) {
      return null;
    }
    return this.authKeys.get(deviceId) || null;
  }
}

export const hardwareAuth = new HardwareAuthService();